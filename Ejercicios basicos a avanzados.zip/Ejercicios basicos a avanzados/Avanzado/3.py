# color codes for console
SUCCESS = "\033[92m"  # Green
RESET = "\033[0m"     # Reset color

# sum of unique elements
def sum_of_unique_elements(list):
    unique_elements = set(list)
    sum = sum(num for num in unique_elements if list.count(num) == 1)
    return sum
list = [1, 2, 2, 3, 4, 4, 4, 5]
result = sum_of_unique_elements(list)
print(f"{SUCCESS} the sum of the unique elements is {RESET}:", result)

