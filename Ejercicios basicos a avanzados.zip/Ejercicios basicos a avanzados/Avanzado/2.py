# color codes for console
SUCCESS = "\033[92m"  # Green
RESET = "\033[0m"     # Reset color

# simulate given
import random
def throw_dice():
    return random.randint(1, 6)
number_of_releases = int(input("How many times do you want to roll the dice?"))
for i in range(number_of_releases):
    result = throw_dice()
    print(f"{SUCCESS}launch {i+1} {RESET}: {result}")