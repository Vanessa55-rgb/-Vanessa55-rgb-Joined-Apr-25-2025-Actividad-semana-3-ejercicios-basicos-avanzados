# color codes for the console
SUCCESS = "\033[92m"  # Green
RESET = "\033[0m"     # Reset color

# validate secure password
import re

def is_password_secure(password):
    if len(password) < 8:
        return False
    if not re.search(r'[A-Z]', password):
        return False
    if not re.search(r'[a-z]', password):
        return False
    if not re.search(r'[0-9]', password):
        return False
    if not re.search(r'[@#$%^&+=!]', password):
        return False
    return True
password = input("enter the password: ")
if is_password_secure(password):
    print(F"{SUCCESS} the password is secure {RESET}")
else:
    print(f"{SUCCESS} the password does not meet the security requirements {RESET}")
