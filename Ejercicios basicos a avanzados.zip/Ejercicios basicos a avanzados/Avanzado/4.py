# color codes for console
SUCCESS = "\033[92m"  # Green
RESET = "\033[0m"     # Reset color

# password generator
import random
import string

def password_generator(length):
    characters = string.ascii_letters + string.digits + string.punctuation
    password = ''.join(random.choice(characters) for _ in range(length))
    return password
while True:
    try:
        length = int(input("enter the desired length for the password: "))
        if length > 0:
            break
        else:
            print("the length must be a positive number")
    except ValueError:
        print("please enter a valid integer.")
generated_password = password_generator(length)
print("{SUCCESS}your generated password is {RESET}: ", generated_password)

