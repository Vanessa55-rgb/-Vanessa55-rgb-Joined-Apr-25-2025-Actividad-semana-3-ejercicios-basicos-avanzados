# color codes for console
SUCCESS = "\033[92m"  # Green
RESET = "\033[0m"     # Reset color

# filter pairs
def filter_pairs(list):
    return [num for num in list if num % 2 == 0]
number_entered = input("enter a number: ")
try:
    number = int(number_entered)
    if number % 2 == 0:
        print(f"the number {number} it's even")
    else:
        print(f"the number {number} is odd")
except ValueError:
    print(f"{SUCCESS} invalid input. Please enter an integer {RESET}")