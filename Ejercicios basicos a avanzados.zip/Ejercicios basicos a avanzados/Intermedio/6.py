# color codes for console
SUCCESS = "\033[92m"  # Green
RESET = "\033[0m"     # Reset color

# count vowels
def count_vowels(string):
    vowels = "aeiou"
    counter = 0
    for letter in string.lower():  
        if letter in vowels:
            counter += 1
    return counter
user_string = input("enter a text string: ")
num_vowels = count_vowels(user_string) 
print(f"{SUCCESS} the number of vowels in the string'{user_string}' is {RESET}: {num_vowels}")

