# color codes for console
SUCCESS = "\033[92m"  # Green
RESET = "\033[0m"     # Reset color

# palindrome
def is_palindrome(text):
    text = text.lower().replace(" ", "")
    return text == text[::-1]
user_text = input("enter a text string: ")
if is_palindrome(user_text):
    print(f"{SUCCESS} the chain '{user_text}' it is a palindrome {RESET}")
else:
    print(f"{SUCCESS} the chain'{user_text}' it is not a palindrome {RESET}")