# color codes for console
SUCCESS = "\033[92m"  # Green
RESET = "\033[0m"     # Reset color

# fizzBuzz
def fizzbuzz(n):
    if n % 3 == 0 and n % 5 == 0:
        return "FizzBuzz"
    elif n % 3 == 0:
        return "Fizz"
    elif n % 5 == 0:
        return "Buzz"
    else:
        return str(n)

while True: 
  try:
    num_input = int(input("enter a positive integer: "))
    if num_input <= 0:
      print(f"{SUCCESS} the number must be positive {RESET}")
      continue 
    break 
  except ValueError:
    print(f"{SUCCESS} invalid input. Please enter an integer {RESET}")
result = fizzbuzz(num_input)
print(result)
