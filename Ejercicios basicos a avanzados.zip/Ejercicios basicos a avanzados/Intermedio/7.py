# color codes for console
SUCCESS = "\033[92m"  # Green
RESET = "\033[0m"     # Reset color

# reverse text
def reverse_text(text):
    return text[::-1]
original_string = input("enter a text string: ")
inverted_string = reverse_text(original_string)
print(f"{SUCCESS} the inverted chain is {RESET}:", inverted_string)