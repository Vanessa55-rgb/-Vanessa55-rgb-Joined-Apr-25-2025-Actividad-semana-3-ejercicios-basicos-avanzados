# color codes for console
SUCCESS = "\033[92m"  # Green
RESET = "\033[0m"     # Reset color

# factorial
def factorial(n):
    if n < 0:
        raise ValueError("the factorial is not defined for negative numbers")
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result
while True:
    try:
        number_entered = int(input("enter a non-negative integer: "))
        break
    except ValueError:
        print("invalid input. Please enter an integer")
if number_entered < 0:
    print("the factorial is not defined for negative numbers")
else:
    result = factorial(number_entered)
    print(f"{SUCCESS} the factorial of {number_entered} is {RESET}: {result}")