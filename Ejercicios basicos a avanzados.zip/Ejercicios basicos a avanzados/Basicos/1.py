# color codes for console
SUCCESS = "\033[92m"  # Green
RESET = "\033[0m"     # Reset color

# personalized greeting
name = input("enter your name: ")
def personalized_greeting(name):
    greeting = (f"{SUCCESS} ¡Hello, {name}!{RESET} ¡I hope you have a great day!!")
    print(greeting)
personalized_greeting(name)