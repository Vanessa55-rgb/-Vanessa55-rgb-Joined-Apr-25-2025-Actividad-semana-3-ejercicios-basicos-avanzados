# color codes for console
SUCCESS = "\033[92m"  # Green
RESET = "\033[0m"     # Reset color

# greater than a list
def elderly(list):
    return max(list)
def get_into_list():
    list_str = input("enter the numbers from the list, separated by commas: ")
    list_number = [float(num) for num in list_str.split(",")]
    return list_number
list_number = get_into_list()
number_elderly = elderly(list_number)
print(f"{SUCCESS} the largest number in the entered list is {RESET}: {number_elderly}")