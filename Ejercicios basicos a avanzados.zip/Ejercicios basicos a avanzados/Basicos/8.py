# color codes for console
SUCCESS = "\033[92m"  # Green
RESET = "\033[0m"     # Reset color

# count letters
def count_letters(word, letter):
    return word.count(letter)
word = input("Ingresa una palabra: ")
letter = input("Ingresa una letra: ")
number_of_times = count_letters(word, letter)
print(f"{SUCCESS} the letter'{letter}'appears {number_of_times} times in '{word} {RESET} '")