# color codes for console
SUCCESS = "\033[92m"  # Green
RESET = "\033[0m"     # Reset color

# coming of age
age = int(input("enter age: "))  
def verify_legal_age(age):
    if age >= 18:
        return "adult"
    else:
        return "under-age"
print(f"{SUCCESS} are {RESET}: {verify_legal_age(age)}")