# color codes for console
SUCCESS = "\033[92m"  # Green
RESET = "\033[0m"     # Reset color

# pair or odd number
number = int(input("enter number: "))
def pair_or_odd(number):
    if number % 2 == 0:
        return "pair"
    else:
        return "odd"
print(f"{SUCCESS} the number is {RESET}: {pair_or_odd(number)}")