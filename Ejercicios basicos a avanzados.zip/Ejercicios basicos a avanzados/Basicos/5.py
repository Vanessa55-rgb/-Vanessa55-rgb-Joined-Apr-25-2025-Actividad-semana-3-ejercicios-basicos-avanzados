# color codes for console
SUCCESS = "\033[92m"  # Green
RESET = "\033[0m"     # Reset color

# temperature converter
celsius = float(input("the temperature in degrees Celsius: "))
def celsius_a_fahrenheit(celsius):
    fahrenheit = (celsius * (9/5)) + 32
    print(f"{SUCCESS} the value of Celsius to Fahrenheit is {RESET}: {fahrenheit}")
celsius_a_fahrenheit(celsius)