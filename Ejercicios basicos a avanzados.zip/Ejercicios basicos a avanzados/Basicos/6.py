# area triangle
base = float(input("enter the base of the triangle: "))
height = float(input("enter the height of the triangle: "))
def triangle_area(base, height):
    area = (base * height) / 2
    print(area)
triangle_area(base,height)