# color codes for console
SUCCESS = "\033[92m"  # Green
RESET = "\033[0m"     # Reset color

# sum of two numbers
a = int(input("enter the number one: "))
b = int(input("Enter the number two: "))
def sum (a, b):
    result = a + b
    return result
print(f"{SUCCESS} the result of the sum is {RESET}: {sum(a, b)}")